<?php
require(VV_INC . '/init.php'); ?>