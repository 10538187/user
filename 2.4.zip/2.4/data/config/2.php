<?php
return array (
  'name' => '������ѧ',
  'from_title' => '������ѧ',
  'from_url' => 'http://www.6mao.com/',
  'charset' => 'gb2312',
  'other_url' => 'www.6mao.com',
  'resdomain' => '*.6mao.com',
  'img_delay_name' => '',
  'search_url' => 'http://zhannei.baidu.com/cse/search',
  'search_charset' => 'utf-8',
  'hidejserror' => '1',
  'licence' => '',
  'body_start' => '',
  'body_end' => '',
  'replacerules' => '<meta charset="utf-8"******<meta charset="gb2312"
##########
html/html******html
##########
(bxwx.la)******
##########
index.php?/******/
##########
Reserved 22******Reserved&nbsp;
##########
class="hotlist c_box"******style="display:none"
##########
{vivisign}images/logo.gif******{vivisign}static/mm/logo.gif
##########
id="imgString"******style="display:none"
##########
class="showFooter"******style="display:none"
##########
www.bxwx.la
##########
init_xiuna();
##########
show_xiuna();
##########
area_xiuna
##########
{vivisign}js/tonji.js******none
##########
{vivisign}js/fenlei.js******none
##########
getImgString()******for (i = 0; i < arrayImg.length; i++) {var arrayimgs = arrayImg[i];arrayimgs = arrayimgs.replace("big", "pic");document.write(\'<img src="\'+arrayimgs+\'">\');}
##########
<div class="header_logo"><a href="">������ѧ</a></div>******<div><a href="/"><img src="/1.png" border="0" alt="������ѧ"></a></div>
##########
<div class="userpanel"><script>banner();</script></div>******
##########
Copyright ?******Copyright &
##########
��վ����С˵Ϊת����Ʒ�������½ھ��������ϴ���ת������վֻ��Ϊ�����������ø���������͡�
##########',
  'siftrules' => '{vivi replace=\'\'}<ul class="imglink">(.*)</ul>{/vivi}[cutline]{vivi replace=\'\'}<ul class="textlink">(.*)</ul>{/vivi}',
  'replace_before_on' => '0',
  'replacerules_before' => '',
  'siftrules_before' => '',
  'css' => '',
  'big52gbk' => '0',
  'replace' => '0',
  'rewrite' => '0',
  'tplfile' => '',
  'cookie' => '',
  'user_agent' => '',
  'referer' => '',
  'ip' => '',
  'ip_type' => '1',
  'zdy' => 
  array (
    0 => 
    array (
      'type' => '0',
      'body' => '',
      'regx' => '',
      'start' => '',
      'end' => '',
    ),
  ),
  'plus' => 'sitemap',
  'siftags' => 
  array (
    0 => 'iframe',
    1 => 'object',
    2 => 'localjs',
  ),
  'time' => 1514276120,
  'domain_fan' => '0',
  'my_domain' => '',
  'from_domain' => '',
  'domain_rules' => '',
  'auto_get_search' => '0',
  'auto301' => '0',
  'charset_force' => '0',
  'no_siteapp' => '0',
  'source_replace' => '',
  'ip_cachetime' => '600',
  'theme_open' => '1',
  'theme_dir' => 'default',
  'theme_showotherurl' => '1',
  'urlrules_list' => '',
  'urlrules_listpage' => '',
  'urlrules_show' => '',
  'urlrules_showpage' => '',
  'rules_body' => '',
  'urlrules_other' => '',
  'theme_sifturl' => '',
  'web_404_type' => 'jump',
  'web_404_url' => '',
  'web_404_str' => '',
  'collect_close' => 1,
  'web_name' => '1',
  'web_seo_name' => '1',
  'web_keywords' => '1',
  'web_description' => '',
  'web_domains' => 'http://www.t.com/',
  'web_tongji' => '',
  'web_close' => 'off',
  'web_closecon' => '',
  'web_debug' => 'off',
  'other_imgurl' => '',
  'cache_set' => '0',
  'csscache' => '0',
  'jscache' => '0',
  'imgcache' => '0',
  'cacheon' => '0',
  'deloldcache' => '0',
  'robotlogon' => '0',
  'indexcache' => '',
  'othercache' => '',
  'imgcachetime' => '',
  'csscachetime' => '',
  'jscachetime' => '',
  'delcache' => '',
  'delcachetime' => '',
  'linkword_set' => '0',
  'linkword_on' => '0',
  'link_config' => '',
  'flink_set' => '0',
  'flink' => '',
);
?>