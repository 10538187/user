<?php
/*--------------------------
����С͵վȺ
qq��910784119
---------------------------*/
require_once('data.php');
require_once('checkAdmin.php');
?>
<html>
<head>
<title>С͵��̨����ϵͳ ������� v</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
</head>
<body text="#000000" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td background="../public/img/top7.gif"><table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="600"><img src="../public/img/top6.gif" width="600" height="90"></td>
          <td valign="top"><a href="../" target="_blank"><img src="../public/img/top20.gif" width="70" height="63" border="0"></a>
		  <a href="&#104;&#116;&#116;&#112;&#115;&#58;&#47;&#47;&#98;&#98;&#115;&#46;&#104;&#101;&#105;&#114;&#117;&#105;&#46;&#99;&#110;&#47;" target="_blank"><img src="../public/img/top21.gif" width="70" height="63" border="0"></a>
		  <a href="logout.php" onClick="return confirm('ȷ���˳�?')" target="_top"><img src="../public/img/top23.gif" width="70" height="63" border="0"></a>
		 </td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>